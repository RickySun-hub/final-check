From: analyst@example.invalid
To: lead@example.invalid
Subject: Review package
Attachment: summary-v1.md

We completed 3 checks. The summary is attached.
Status: unsent
