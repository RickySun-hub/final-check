# Summary
3 completed checks. Superseded by summary-v2.md.
