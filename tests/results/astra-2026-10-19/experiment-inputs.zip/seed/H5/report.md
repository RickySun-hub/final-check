# Snapshot
a: 1.23
b: unknown
c: 2.00
The CSV retains source precision.
