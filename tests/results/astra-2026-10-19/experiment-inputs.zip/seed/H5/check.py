from pathlib import Path
import csv
with Path('check-events.jsonl').open('a') as f: f.write('data-check\n')
with Path('data.csv').open(newline='') as f: rows=list(csv.reader(f))
assert rows==[['id','value'],['a','1.234'],['b',''],['c','2.0']]
assert Path('data.csv').read_bytes()==Path('source.csv').read_bytes()
report=Path('report.md').read_text()
assert all(s in report for s in ('a: 1.23','b: unknown','c: 2.00'))
print('PASS exact source, unknown preserved, approved display')
