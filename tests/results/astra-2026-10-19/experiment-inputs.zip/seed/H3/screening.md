# Screening
B is the best candidate for the 1550 nm TE requirement, efficiency 0.89. All completed jobs are valid optical candidates. A has the best training loss.
