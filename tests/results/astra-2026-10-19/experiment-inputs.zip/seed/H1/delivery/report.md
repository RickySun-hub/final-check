# June Completion Review
Data: June snapshot. Handoff: July 2.
North success rate: 33.3%. South success rate: 66.7%.
Included: export.csv.
