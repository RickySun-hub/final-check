Local package: price total uses tax.json; authentication is local fixture only.
