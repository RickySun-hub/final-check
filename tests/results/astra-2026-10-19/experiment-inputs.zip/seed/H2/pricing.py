import json
from pathlib import Path
def total(amount):
    cfg=json.loads(Path("tax.json").read_text())
    return round(amount*(1+cfg["rate"]),2)
