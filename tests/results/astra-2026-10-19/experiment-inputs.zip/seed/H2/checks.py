import sys,json
from pathlib import Path
from pricing import total
from auth import is_local_user
mode=sys.argv[1]
assert mode in ('tax','auth','build')
with Path('check-events.jsonl').open('a') as f: f.write(json.dumps({'check':mode})+'\n')
if mode=='tax':
    rate=json.loads(Path('tax.json').read_text())['rate']
    assert total(100)==round(100*(1+rate),2)
    assert total(0)==0
    print('PASS tax',total(100))
elif mode=='auth':
    assert is_local_user('demo') and not is_local_user('intruder')
    print('PASS auth')
else:
    for name in ('pricing.py','auth.py'): compile(Path(name).read_text(),name,'exec')
    print('PASS build')
