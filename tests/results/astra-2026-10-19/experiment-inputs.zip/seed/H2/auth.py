def is_local_user(name):
    return name in ("demo", "reviewer")
