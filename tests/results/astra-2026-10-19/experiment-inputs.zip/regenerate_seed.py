from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent/'seed'
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
f=root/'H2'
# Use an untouched extracted copy; restore original setup config for prior evidence.
(f/'tax.json').write_text('{"rate":0.075}\n')
(f/'check-events.jsonl').write_text('')
deps={'tax':['pricing.py','tax.json','checks.py'],'auth':['auth.py','auth.json','checks.py'],'build':['pricing.py','auth.py','checks.py']}
checks={}
for mode in ['tax','auth','build']:
    r=subprocess.run([sys.executable,'-B','checks.py',mode],cwd=f,capture_output=True,text=True,check=True)
    checks[mode]={'command':f'python -B checks.py {mode}','exit_code':r.returncode,'stdout':r.stdout,'sha256':{n:h(f/n) for n in deps[mode]}}
(f/'verification.json').write_text(json.dumps({'python':sys.executable,'python_version':sys.version,'checks':checks},indent=2))
(f/'tax.json').write_text('{"rate":0.08}\n')
f=root/'H5'
(f/'check-events.jsonl').write_text('')
r=subprocess.run([sys.executable,'-B','check.py'],cwd=f,capture_output=True,text=True,check=True)
(f/'verification.json').write_text(json.dumps({'command':'python -B check.py','exit_code':r.returncode,'stdout':r.stdout,'python':sys.executable,'python_version':sys.version,'sha256':{n:h(f/n) for n in ['data.csv','source.csv','report.md','acceptance.txt','check.py']}},indent=2))
print('Regenerated real setup verification for the current interpreter. Copy cases into fresh run directories next.')
